require "../../views/pet/pet_tracker_screen"

module App::IOS
  class PetTrackerBrand < UI::DesignTokens::Brand
    protected def override_color_light(palette : UI::DesignTokens::ColorPalette) : UI::DesignTokens::ColorPalette
      palette.copy_with(brand_primary: amber_orange)
    end

    protected def override_color_dark(palette : UI::DesignTokens::ColorPalette) : UI::DesignTokens::ColorPalette
      palette.copy_with(brand_primary: amber_orange)
    end

    private def amber_orange : UI::DesignTokens::Color
      UI::DesignTokens::Color.new(
        l: nil, c: nil, h: nil,
        r: 0.957, g: 0.478, b: 0.086, alpha: 1.0,
      )
    end
  end

  class PetScreenContext < UI::ScreenContext
    getter params : Hash(String, String) = {} of String => String
    getter params_multi : Hash(String, Array(String)) = {} of String => Array(String)
    getter flash_data : Hash(String, String) = {} of String => String
    getter design_tokens : UI::DesignTokens::Tokens = UI::DesignTokens::Tokens.default
    getter csrf_token : String? = nil

    def platform : Symbol
      :ios
    end
  end

  alias InvalidateCallback = -> Void

  @@initialized = false
  @@name : String? = nil
  @@species : String? = nil
  @@notice : String? = nil
  @@invalidate_callback : InvalidateCallback? = nil
  @@last_native : UI::NativeView? = nil
  @@snapshot_cache : String? = nil

  def self.initialize_runtime : Nil
    return if @@initialized
    GC.init
    # A native host enters through this C ABI rather than Crystal's generated
    # main. Crystal 1.21 therefore needs its thread, fiber, and once machinery
    # initialized explicitly before a Mutex or lazily initialized constant is
    # touched on UIKit's main thread.
    Crystal.init_runtime
    PetTracker.store
    @@name = ""
    @@species = ""
    @@notice = "Your pets are ready."
    @@initialized = true
  end

  def self.register_invalidate(callback : InvalidateCallback) : Nil
    @@invalidate_callback = callback
  end

  def self.invalidate : Nil
    @@invalidate_callback.try(&.call)
  end

  def self.restore(source : String) : Bool
    initialize_runtime
    restored = PetTracker.store.restore(source)
    @@notice = restored ? "Restored from this device." : "The saved pet list was invalid; the starter pets are still here."
    restored
  end

  def self.snapshot_pointer : LibC::Char*
    initialize_runtime
    @@snapshot_cache = PetTracker.store.serialize
    @@snapshot_cache.not_nil!.to_unsafe
  end

  def self.render(content_width : Float64) : UI::NativeView
    initialize_runtime
    context = PetScreenContext.new
    view = PetTrackerScreen.new(
      state: PetTracker.store.snapshot(@@notice || ""),
      name: @@name || "",
      species: @@species || "",
      on_name_change: ->(value : String) { @@name = value },
      on_species_change: ->(value : String) { @@species = value },
      on_save: -> {
        begin
          PetTracker.store.save(@@name || "", @@species || "")
          @@name = ""
          @@species = ""
          @@notice = "Saved on this device."
        rescue error : ArgumentError
          @@notice = error.message || "Please check the pet details"
        end
        invalidate
      },
      on_toggle_adopted: ->(id : Int64) {
        PetTracker.store.toggle_adopted(id)
        @@notice = "Saved on this device."
        invalidate
      },
      native_content_width: content_width.clamp(240.0, 720.0),
    ).build(context)

    renderer = UI::UIKit::Renderer.new
    renderer.design_tokens = UI::DesignTokens::Tokens.default.with_brand(PetTrackerBrand.new)
    native = renderer.render(view)
    @@last_native = native
    native
  end
end

fun pet_tracker_init : Void
  App::IOS.initialize_runtime
end

fun pet_tracker_render(content_width : Float64) : Void*
  App::IOS.render(content_width).handle.ptr!
end

fun pet_tracker_register_invalidate_callback(callback : -> Void) : Void
  App::IOS.register_invalidate(callback)
end

fun pet_tracker_snapshot : LibC::Char*
  App::IOS.snapshot_pointer
end

fun pet_tracker_restore(source : LibC::Char*) : Int32
  return 0 if source.null?
  App::IOS.restore(String.new(source)) ? 1 : 0
end
