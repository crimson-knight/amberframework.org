require "json"

struct PetSummary
  include JSON::Serializable

  getter id : Int64
  getter name : String
  getter species : String
  getter adopted : Bool

  def initialize(@id : Int64, @name : String, @species : String, @adopted : Bool = false)
  end
end

struct PetTrackerState
  getter pets : Array(PetSummary)
  getter notice : String

  def initialize(@pets : Array(PetSummary), @notice : String = "")
  end
end

module PetTracker
  class Store
    @mutex = Mutex.new
    @pets : Array(PetSummary)

    def initialize(@pets = self.class.seed)
    end

    def self.seed : Array(PetSummary)
      [
        PetSummary.new(1_i64, "Mochi", "Cat", true),
        PetSummary.new(2_i64, "Rocky", "Dog", false),
        PetSummary.new(3_i64, "Pip", "Rabbit", false),
      ]
    end

    def snapshot(notice : String = "") : PetTrackerState
      @mutex.synchronize { PetTrackerState.new(@pets.dup, notice) }
    end

    def save(name : String, species : String) : PetSummary
      clean_name = name.strip
      clean_species = species.strip
      raise ArgumentError.new("Name is required") if clean_name.empty?
      raise ArgumentError.new("Species is required") if clean_species.empty?

      @mutex.synchronize do
        next_id = (@pets.max_of?(&.id) || 0_i64) + 1_i64
        pet = PetSummary.new(next_id, clean_name, clean_species)
        @pets << pet
        pet
      end
    end

    def toggle_adopted(id : Int64) : PetSummary
      @mutex.synchronize do
        index = @pets.index { |pet| pet.id == id }
        raise ArgumentError.new("Pet #{id} was not found") unless index
        current = @pets[index]
        updated = PetSummary.new(current.id, current.name, current.species, !current.adopted)
        @pets[index] = updated
        updated
      end
    end

    def serialize : String
      @mutex.synchronize { @pets.to_json }
    end

    def restore(source : String) : Bool
      restored = Array(PetSummary).from_json(source)
      @mutex.synchronize { @pets = restored }
      true
    rescue JSON::ParseException
      false
    end
  end

  # Crystal's embedded iOS entrypoint does not run the ordinary top-level
  # initializer path. A nil-backed lazy singleton gives every host the same
  # store while remaining safe when Swift enters through the C ABI first.
  @@store : Store? = nil

  def self.store : Store
    @@store ||= Store.new
  end
end
