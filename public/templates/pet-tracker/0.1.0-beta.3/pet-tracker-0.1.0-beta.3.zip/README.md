# {{display_name}}

This project was generated from Amber's versioned Pet Tracker starter. The web
server, Android package, and iOS app build the same `PetTrackerScreen` from
`src/views/pet/pet_tracker_screen.cr`; each target supplies its own host and
event adapter.

The starter version and both delivery hashes are recorded in
`.amber-template.lock.json`.

## Web

```sh
shards install
crystal spec
crystal run src/{{app_name}}_web.cr
```

Open <http://127.0.0.1:3000>. Resize the browser to see the same rendered tree
fold into the mobile-web layout.

## Android

```sh
bash mobile/android/android.sh doctor
bash mobile/android/android.sh test emulator-5554
```

The Android host renders native Views and persists its own pet snapshot. The
web and installed app share source and rules; synchronizing records between
processes requires an API repository.

## iOS

```sh
bash mobile/ios/ios.sh doctor
bash mobile/ios/ios.sh test <simulator-udid>
```

The iOS host cross-compiles the shared Crystal screen, renders it through
AssetPipeline's UIKit renderer, packages the same pet portraits in an asset
catalog, and persists the snapshot in `UserDefaults`. The UI test adds Mabel,
terminates the app, launches a fresh process, and verifies restoration.
