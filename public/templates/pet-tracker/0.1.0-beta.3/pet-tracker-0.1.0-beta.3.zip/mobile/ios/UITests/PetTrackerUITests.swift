import XCTest

final class PetTrackerUITests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    func testAddPetAndRestoreItAfterAColdLaunch() throws {
        let app = XCUIApplication()
        app.launchEnvironment["PET_TRACKER_RESET"] = "1"
        app.launch()

        XCTAssertTrue(app.staticTexts["pet-title"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["pet-title"].isHittable)
        let brandMark = app.descendants(matching: .any)
            .matching(identifier: "pet-brand-mark").firstMatch
        XCTAssertTrue(brandMark.waitForExistence(timeout: 5))
        XCTAssertTrue(brandMark.isHittable)

        let name = app.textFields["pet-name"]
        XCTAssertTrue(name.waitForExistence(timeout: 5))
        name.tap()
        name.typeText("Mabel")

        let species = app.textFields["pet-species"]
        species.tap()
        species.typeText("Dog")

        let save = app.buttons["save-pet"]
        XCTAssertTrue(save.waitForExistence(timeout: 5))
        if !save.isHittable {
            app.swipeUp()
        }
        XCTAssertTrue(save.isHittable)
        save.tap()

        XCTAssertTrue(app.staticTexts["pet-name-4"].waitForExistence(timeout: 10))
        app.terminate()

        let restored = XCUIApplication()
        restored.launchEnvironment["PET_TRACKER_RESET"] = "0"
        restored.launch()
        XCTAssertTrue(restored.staticTexts["pet-name-4"].waitForExistence(timeout: 15))

        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = "pet-tracker-ios-restored"
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
