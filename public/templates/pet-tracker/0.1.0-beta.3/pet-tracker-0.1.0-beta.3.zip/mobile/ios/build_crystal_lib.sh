#!/usr/bin/env bash
set -euo pipefail

CRYSTAL="${CRYSTAL:-crystal-alpha}"
BUILD_TARGET="${1:-simulator}"
MIN_IOS_VERSION="${MIN_IOS_VERSION:-17.0}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BUILD_DIR="$SCRIPT_DIR/build"
CROSS_DEPS_ROOT="$BUILD_DIR/cross-deps"
BRIDGE_SOURCE="$PROJECT_ROOT/src/platform/ios/app.cr"
BRIDGE_BASE="$BUILD_DIR/pet_tracker_bridge"
OUTPUT_LIBRARY="$BUILD_DIR/lib{{snake_case}}.a"
ASSET_PIPELINE_ROOT="$PROJECT_ROOT/lib/asset_pipeline"

case "$BUILD_TARGET" in
  simulator)
    CLANG_TARGET="arm64-apple-ios-simulator"
    CRYSTAL_TARGET="$CLANG_TARGET"
    SDK_NAME="iphonesimulator"
    DEPS_KIND="ios-simulator"
    SWIFTKIT_OUTPUT="$BUILD_DIR/swiftkit_simulator.a"
    ;;
  device)
    CLANG_TARGET="arm64-apple-ios"
    CRYSTAL_TARGET="$CLANG_TARGET"
    SDK_NAME="iphoneos"
    DEPS_KIND="ios-device"
    SWIFTKIT_OUTPUT="$BUILD_DIR/swiftkit_device.a"
    ;;
  *)
    echo "Usage: $0 [simulator|device]" >&2
    exit 1
    ;;
esac

for command in "$CRYSTAL" xcrun xcodebuild swift cmake; do
  command -v "$command" >/dev/null 2>&1 || { echo "Missing required command: $command" >&2; exit 1; }
done

SDK_PATH="$(xcrun --sdk "$SDK_NAME" --show-sdk-path)"
CLANG="$(xcrun --sdk "$SDK_NAME" --find clang)"
DEPS_LIB="$CROSS_DEPS_ROOT/$DEPS_KIND/lib"
mkdir -p "$BUILD_DIR" "$DEPS_LIB"

if [[ ! -f "$DEPS_LIB/libgc.a" || ! -f "$DEPS_LIB/libpcre2-8.a" ]]; then
  if [[ -n "${IOS_DEPS_SOURCE:-}" ]]; then
    cp "$IOS_DEPS_SOURCE/libgc.a" "$IOS_DEPS_SOURCE/libpcre2-8.a" "$DEPS_LIB/"
  else
    BUILD_DIR="$CROSS_DEPS_ROOT" IOS_DEPLOYMENT_TARGET="$MIN_IOS_VERSION" \
      "$ASSET_PIPELINE_ROOT/scripts/cross_compile_deps.sh" ios
  fi
fi

OBJC_OBJECT="$BUILD_DIR/objc_bridge_ios.o"
SWIFTKIT_OBJECT="$BUILD_DIR/swiftkit_bridge_ios.o"
"$CLANG" -c "$ASSET_PIPELINE_ROOT/src/ui/native/objc_bridge.m" -o "$OBJC_OBJECT" \
  -target "$CLANG_TARGET" -isysroot "$SDK_PATH" -mios-version-min="$MIN_IOS_VERSION" -fno-objc-arc
"$CLANG" -c "$ASSET_PIPELINE_ROOT/src/ui/native/swiftkit_bridge.m" -o "$SWIFTKIT_OBJECT" \
  -target "$CLANG_TARGET" -isysroot "$SDK_PATH" -mios-version-min="$MIN_IOS_VERSION" -fno-objc-arc

SWIFTKIT_PACKAGE="$ASSET_PIPELINE_ROOT/swift/AssetPipelineSwiftKit"
swift build -c release --package-path "$SWIFTKIT_PACKAGE" --triple "$CLANG_TARGET" --sdk "$SDK_PATH"
cp "$SWIFTKIT_PACKAGE/.build/$CLANG_TARGET/release/libAssetPipelineSwiftKit.a" "$SWIFTKIT_OUTPUT"

(cd "$PROJECT_ROOT" && "$CRYSTAL" build "$BRIDGE_SOURCE" \
  --cross-compile --target="$CRYSTAL_TARGET" -Dios -Dwithout_mt \
  -Dwithout_openssl -Dwithout_xml -o "$BRIDGE_BASE")

if [[ -f "$BRIDGE_BASE.o" ]]; then
  ld -r -unexported_symbol _main "$BRIDGE_BASE.o" -o "$BUILD_DIR/pet_tracker_bridge_fixed.o"
  mv "$BUILD_DIR/pet_tracker_bridge_fixed.o" "$BRIDGE_BASE.o"
fi

ar rcs "$OUTPUT_LIBRARY" "$BRIDGE_BASE.o" "$OBJC_OBJECT" "$SWIFTKIT_OBJECT"
echo "Built $OUTPUT_LIBRARY for $BUILD_TARGET"
