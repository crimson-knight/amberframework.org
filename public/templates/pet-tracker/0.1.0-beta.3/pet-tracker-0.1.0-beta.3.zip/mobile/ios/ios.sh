#!/usr/bin/env bash
set -euo pipefail

ACTION="${1:-doctor}"
DEVICE="${2:-${IOS_SIMULATOR_UDID:-}}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
DERIVED_DATA="$SCRIPT_DIR/build/DerivedData"
SCHEME="{{pascal_case}}"

doctor() {
  for command in crystal xcodebuild xcrun xcodegen swift; do
    command -v "$command" >/dev/null 2>&1 || { echo "Missing required command: $command" >&2; exit 1; }
  done
  xcodebuild -version
  xcrun --sdk iphonesimulator --show-sdk-path
  echo "iOS toolchain is ready."
}

generate_and_build() {
  "$SCRIPT_DIR/build_crystal_lib.sh" simulator
  (cd "$SCRIPT_DIR" && xcodegen generate --spec project.yml)
  xcodebuild \
    -project "$SCRIPT_DIR/$SCHEME.xcodeproj" \
    -scheme "$SCHEME" \
    -sdk iphonesimulator \
    -destination 'generic/platform=iOS Simulator' \
    -derivedDataPath "$DERIVED_DATA" \
    build
}

case "$ACTION" in
  doctor)
    doctor
    ;;
  build)
    doctor
    generate_and_build
    ;;
  test)
    [[ -n "$DEVICE" ]] || { echo "Usage: $0 test <simulator-udid>" >&2; exit 1; }
    doctor
    "$SCRIPT_DIR/build_crystal_lib.sh" simulator
    (cd "$SCRIPT_DIR" && xcodegen generate --spec project.yml)
    rm -rf "$SCRIPT_DIR/build/PetTrackerTests.xcresult"
    xcodebuild \
      -project "$SCRIPT_DIR/$SCHEME.xcodeproj" \
      -scheme "$SCHEME" \
      -destination "platform=iOS Simulator,id=$DEVICE" \
      -derivedDataPath "$DERIVED_DATA" \
      -resultBundlePath "$SCRIPT_DIR/build/PetTrackerTests.xcresult" \
      test
    ;;
  run)
    [[ -n "$DEVICE" ]] || { echo "Usage: $0 run <simulator-udid>" >&2; exit 1; }
    doctor
    generate_and_build
    xcrun simctl bootstatus "$DEVICE" -b
    APP_PATH="$DERIVED_DATA/Build/Products/Debug-iphonesimulator/$SCHEME.app"
    xcrun simctl install "$DEVICE" "$APP_PATH"
    xcrun simctl launch --terminate-running-process "$DEVICE" dev.amber.generated.pettracker
    ;;
  *)
    echo "Usage: $0 [doctor|build|test|run] [simulator-udid]" >&2
    exit 1
    ;;
esac
