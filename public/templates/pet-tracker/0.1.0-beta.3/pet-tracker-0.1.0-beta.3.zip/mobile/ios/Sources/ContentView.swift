import SwiftUI
import UIKit

struct ContentView: View {
    @State private var renderVersion = 0

    var body: some View {
        GeometryReader { geometry in
            ScrollView(.vertical, showsIndicators: false) {
                PetTrackerHost(contentWidth: max(240, geometry.size.width - 48))
                    .id(renderVersion)
                    .frame(width: geometry.size.width, alignment: .top)
                    .accessibilityIdentifier("pet-tracker-host")
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(Color(red: 1.0, green: 0.976, blue: 0.937))
        }
        .background(Color(red: 1.0, green: 0.976, blue: 0.937).ignoresSafeArea())
        .onReceive(PetTrackerBridge.invalidated) { _ in
            renderVersion += 1
        }
    }
}

struct PetTrackerHost: UIViewRepresentable {
    let contentWidth: CGFloat

    func makeUIView(context: Context) -> UIView {
        guard let crystalRoot = PetTrackerBridge.render(contentWidth: contentWidth) else {
            let fallback = UILabel()
            fallback.text = "Pet Tracker could not start."
            fallback.accessibilityIdentifier = "pet-tracker-render-failed"
            return fallback
        }

        return crystalRoot
    }

    func updateUIView(_ uiView: UIView, context: Context) {}

    @available(iOS 16.0, *)
    func sizeThatFits(
        _ proposal: ProposedViewSize,
        uiView: UIView,
        context: Context
    ) -> CGSize? {
        let width = proposal.width ?? contentWidth + 48
        let fittingSize = uiView.systemLayoutSizeFitting(
            CGSize(width: width, height: UIView.layoutFittingCompressedSize.height),
            withHorizontalFittingPriority: .required,
            verticalFittingPriority: .fittingSizeLevel
        )
        return CGSize(width: width, height: max(1, fittingSize.height))
    }
}
