import Combine
import UIKit

enum PetTrackerBridge {
    private static let snapshotKey = "pet-tracker.snapshot.v1"
    private static var initialized = false

    static let invalidated = PassthroughSubject<Void, Never>()

    private static let invalidateThunk: @convention(c) () -> Void = {
        DispatchQueue.main.async {
            persistSnapshot()
            invalidated.send(())
        }
    }

    static func initialize() {
        guard !initialized else { return }

        pet_tracker_init()
        if ProcessInfo.processInfo.environment["PET_TRACKER_RESET"] == "1" {
            UserDefaults.standard.removeObject(forKey: snapshotKey)
        }
        if let snapshot = UserDefaults.standard.string(forKey: snapshotKey) {
            snapshot.withCString { source in
                _ = pet_tracker_restore(source)
            }
        }
        pet_tracker_register_invalidate_callback(invalidateThunk)
        initialized = true
    }

    static func render(contentWidth: CGFloat) -> UIView? {
        initialize()
        guard let raw = pet_tracker_render(Double(contentWidth)) else { return nil }
        let view = Unmanaged<UIView>.fromOpaque(raw).takeRetainedValue()
        view.accessibilityIdentifier = "pet-tracker-screen"
        view.isAccessibilityElement = false
        return view
    }

    private static func persistSnapshot() {
        guard let source = pet_tracker_snapshot() else { return }
        UserDefaults.standard.set(String(cString: source), forKey: snapshotKey)
    }
}
