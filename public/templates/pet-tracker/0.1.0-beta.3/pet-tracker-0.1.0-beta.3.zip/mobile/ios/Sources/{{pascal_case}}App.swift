import SwiftUI

@main
struct {{pascal_case}}App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
        }
    }
}
