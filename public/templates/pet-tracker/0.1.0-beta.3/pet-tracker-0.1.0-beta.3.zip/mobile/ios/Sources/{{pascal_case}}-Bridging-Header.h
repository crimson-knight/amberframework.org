#ifndef PetTracker_Bridging_Header_h
#define PetTracker_Bridging_Header_h

#import <UIKit/UIKit.h>

void pet_tracker_init(void);
void *pet_tracker_render(double content_width);
void pet_tracker_register_invalidate_callback(void (*callback)(void));
const char *pet_tracker_snapshot(void);
int pet_tracker_restore(const char *source);

#endif
