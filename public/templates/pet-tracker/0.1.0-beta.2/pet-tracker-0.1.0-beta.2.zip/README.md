# {{display_name}}

This project was generated from Amber's versioned Pet Tracker starter. The web
server and Android package build the same `PetTrackerScreen` from
`src/views/pet/pet_tracker_screen.cr`; each target supplies its own host and
event adapter.

The starter version and both delivery hashes are recorded in
`.amber-template.lock.json`.

## Web

```sh
shards install
crystal spec
crystal run src/{{app_name}}_web.cr
```

Open <http://127.0.0.1:3000>. Resize the browser to see the same rendered tree
fold into the mobile-web layout.

## Android

```sh
bash mobile/android/android.sh doctor
bash mobile/android/android.sh test emulator-5554
```

The Android host renders native Views and persists its own pet snapshot. The
web and installed app share source and rules; synchronizing records between
processes requires an API repository.
