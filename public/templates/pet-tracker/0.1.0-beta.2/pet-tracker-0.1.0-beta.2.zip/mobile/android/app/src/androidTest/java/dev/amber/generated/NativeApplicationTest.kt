package dev.amber.generated

import android.widget.EditText
import android.widget.ImageView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.replaceText
import androidx.test.espresso.action.ViewActions.scrollTo
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import androidx.test.espresso.matcher.ViewMatchers.withHint
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import dev.assetpipeline.androidhost.NativeTestIds
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.hamcrest.Matchers.allOf

@RunWith(AndroidJUnit4::class)
class NativeApplicationTest {
    private fun awaitText(text: String) {
        val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        assertTrue("Native view did not display: $text", device.wait(Until.hasObject(By.text(text)), 10_000L))
    }

    @Test
    fun sharedPetScreenRendersImagesAndHandlesTheForm() {
        ActivityScenario.launch(MainActivity::class.java).use {
            awaitText("Pet Tracker")
            onView(NativeTestIds.withTestId("pet-avatar-1")).check { view, error ->
                if (error != null) throw error
                assertNotNull((view as ImageView).drawable)
            }
            onView(allOf(isAssignableFrom(EditText::class.java), withHint("Enter a name")))
                .perform(scrollTo(), replaceText("Mabel"))
            onView(allOf(isAssignableFrom(EditText::class.java), withHint("Select a species")))
                .perform(scrollTo(), replaceText("Dog"))
            onView(NativeTestIds.withTestId("save-pet")).perform(scrollTo(), click())
            awaitText("Saved on this device.")
            onView(withText("Mabel")).check(matches(withText("Mabel")))
        }
    }
}
