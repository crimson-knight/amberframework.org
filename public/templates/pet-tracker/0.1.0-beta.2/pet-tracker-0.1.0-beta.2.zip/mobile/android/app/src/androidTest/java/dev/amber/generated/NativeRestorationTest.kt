package dev.amber.generated

import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NativeRestorationTest {
    private fun awaitText(text: String) {
        val device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        assertTrue("Restored native view did not display: $text", device.wait(Until.hasObject(By.text(text)), 10_000L))
    }

    @Test
    fun savedPetSnapshotSurvivesAColdProcess() {
        ActivityScenario.launch(MainActivity::class.java).use {
            awaitText("Pet Tracker")
            awaitText("Restored from this device.")
            onView(withText("Mochi")).check(matches(withText("Mochi")))
            onView(withText("Rocky")).check(matches(withText("Rocky")))
            onView(withText("Pip")).check(matches(withText("Pip")))
            onView(withText("Mabel")).check(matches(withText("Mabel")))
        }
    }
}
