#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "$0")" && pwd)"
project_root="$(cd "$script_dir/../.." && pwd)"
asset_root="$project_root/lib/asset_pipeline"
[[ -f "$asset_root/scripts/android_env.sh" ]] || { echo "Install the Android-capable AssetPipeline shard first." >&2; exit 1; }
source "$asset_root/scripts/android_env.sh"
android_resolve_sdk_root
android_resolve_java_home
export ANDROID_SDK_ROOT="$ANDROID_RESOLVED_SDK_ROOT"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export JAVA_HOME="$ANDROID_RESOLVED_JAVA_HOME"
adb="$ANDROID_SDK_ROOT/platform-tools/adb"
action="${1:-build}"
serial="${2:-}"
setting() { awk -F= -v key="$1" '$1 == key { sub(/^[^=]*=/, ""); print; exit }' "$script_dir/android-app.properties"; }
app_id="$(setting applicationId)"
cd "$script_dir"
case "$action" in
  doctor) exec bash "$asset_root/scripts/doctor_android.sh" ;;
  build)
    ./gradlew :app:assembleDebug :app:assembleRelease :app:bundleRelease --console=plain
    exec bash "$script_dir/inspect_artifacts.sh"
    ;;
  run|test) ;;
  *) echo "Usage: $0 doctor|build|run|test [adb-serial]" >&2; exit 2 ;;
esac
[[ -n "$serial" ]] || { echo "Specify an ADB serial. No device test has been run." >&2; exit 2; }
[[ "$("$adb" -s "$serial" get-state)" == device ]] || { echo "ADB target is not ready: $serial" >&2; exit 1; }
[[ "$("$adb" -s "$serial" shell getprop sys.boot_completed | tr -d '\r')" == 1 ]] || { echo "Android has not completed boot: $serial" >&2; exit 1; }
# A freshly booted CI emulator can sit on the keyguard, and the API 35 x86_64
# image boots into a launcher "isn't responding" dialog, a system alert window
# that covers the app and swallows every wait: wake, dismiss, close the system
# dialogs, and hide error dialogs for the run (restored on exit), as
# AssetPipeline's own driver does.
"$adb" -s "$serial" shell input keyevent KEYCODE_WAKEUP > /dev/null 2>&1 || true
"$adb" -s "$serial" shell wm dismiss-keyguard > /dev/null 2>&1 || true
"$adb" -s "$serial" shell am broadcast -a android.intent.action.CLOSE_SYSTEM_DIALOGS > /dev/null 2>&1 || true
previous_hide_error_dialogs="$("$adb" -s "$serial" shell settings get global hide_error_dialogs 2>/dev/null | tr -d '\r')"
restore_hide_error_dialogs() {
  if [[ -z "$previous_hide_error_dialogs" || "$previous_hide_error_dialogs" == null ]]; then
    "$adb" -s "$serial" shell settings delete global hide_error_dialogs > /dev/null 2>&1 || true
  else
    "$adb" -s "$serial" shell settings put global hide_error_dialogs "$previous_hide_error_dialogs" > /dev/null 2>&1 || true
  fi
}
trap restore_hide_error_dialogs EXIT
"$adb" -s "$serial" shell settings put global hide_error_dialogs 1 > /dev/null 2>&1 || true
for _ in 1 2 3; do "$adb" -s "$serial" shell input keyevent KEYCODE_BACK > /dev/null 2>&1 || true; done
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:assembleDebugAndroidTest :app:assembleRelease :app:bundleRelease --console=plain
# Start from the same state as a reader installing the generated app for the
# first time. This also prevents an earlier local run from making persistence
# assertions pass with stale app data.
"$adb" -s "$serial" uninstall "$app_id.test" > /dev/null 2>&1 || true
"$adb" -s "$serial" uninstall "$app_id" > /dev/null 2>&1 || true
"$adb" -s "$serial" install app/build/outputs/apk/debug/app-debug.apk
if [[ "$action" == run ]]; then
  exec "$adb" -s "$serial" shell am start -S -W -n "$app_id/dev.amber.generated.MainActivity"
fi
"$adb" -s "$serial" install app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk
previous_checkjni="$("$adb" -s "$serial" shell getprop debug.checkjni | tr -d '\r')"
restore_checkjni() { "$adb" -s "$serial" shell setprop debug.checkjni "${previous_checkjni:-0}" > /dev/null 2>&1 || true; }
trap restore_checkjni EXIT
"$adb" -s "$serial" shell setprop debug.checkjni 1
[[ "$("$adb" -s "$serial" shell getprop debug.checkjni | tr -d '\r')" == 1 ]]
evidence="${ANDROID_TEST_EVIDENCE:-$project_root/build/android-test-evidence}"
mkdir -p "$evidence"
host_test_report="app/build/test-results/testDebugUnitTest/TEST-dev.assetpipeline.androidhost.HostSessionTest.xml"
[[ -s "$host_test_report" ]] || { echo "Missing canonical host-session unit test report" >&2; exit 1; }
grep -Eq '<testsuite .*tests="[1-9][0-9]*".*failures="0".*errors="0"' "$host_test_report" || {
  echo "Host-session unit tests were empty or failed" >&2; exit 1;
}
cp "$host_test_report" "$evidence/host-session-unit-tests.xml"
service_test_report="app/build/test-results/testDebugUnitTest/TEST-dev.assetpipeline.androidhost.ServiceQueueTest.xml"
[[ -s "$service_test_report" ]] || { echo "Missing canonical service-queue unit test report" >&2; exit 1; }
grep -Eq '<testsuite .*tests="[1-9][0-9]*".*failures="0".*errors="0"' "$service_test_report" || {
  echo "Service-queue unit tests were empty or failed" >&2; exit 1;
}
cp "$service_test_report" "$evidence/service-queue-unit-tests.xml"
for suite in HttpWireTest PlatformHttpTest SecretVaultTest FilePolicyTest NotificationWireTest PermissionRequestsTest EditorActionsTest LayoutPolicyTest ViewStatePolicyTest SemanticsPolicyTest CompoundFocusPolicyTest DialogPolicyTest SheetPolicyTest; do
  report="app/build/test-results/testDebugUnitTest/TEST-dev.assetpipeline.androidhost.$suite.xml"
  [[ -s "$report" ]] || { echo "Missing canonical service unit test report: $suite" >&2; exit 1; }
  grep -Eq '<testsuite .*tests="[1-9][0-9]*".*failures="0".*errors="0"' "$report" || {
    echo "Service unit tests were empty or failed: $suite" >&2; exit 1;
  }
  cp "$report" "$evidence/$suite.xml"
done
log_start="$("$adb" -s "$serial" shell "date '+%m-%d %H:%M:%S.000'" | tr -d '\r')"
# Stream the log from here on: a slow emulator writes enough during the suite to
# wrap its buffer, and a dump taken afterward would no longer hold the runtime's
# load line. The streamed file plus a final dump is what every check reads.
"$adb" -s "$serial" logcat -v threadtime -T "$log_start" > "$evidence/logcat-live.txt" 2> "$evidence/logcat-capture-stderr.txt" &
live_logcat_pid=$!
stop_live_logcat() { kill "$live_logcat_pid" 2>/dev/null || true; wait "$live_logcat_pid" 2>/dev/null || true; }
cleanup_android_test() {
  stop_live_logcat
  restore_checkjni
  restore_hide_error_dialogs
}
trap cleanup_android_test EXIT
"$adb" -s "$serial" shell am instrument -w -r -e class dev.amber.generated.NativeApplicationTest,dev.assetpipeline.androidhost.StoragePlatformTest,dev.assetpipeline.androidhost.SecretsPlatformTest,dev.assetpipeline.androidhost.FilesPlatformTest \
  "$app_id.test/androidx.test.runner.AndroidJUnitRunner" > "$evidence/instrumentation.txt" 2>&1
if ! grep -Eq '^OK \([1-9][0-9]* tests?\)' "$evidence/instrumentation.txt" ||
    ! grep -q '^INSTRUMENTATION_CODE: -1' "$evidence/instrumentation.txt" ||
    grep -Eq 'Process crashed|FAILURES!!!|INSTRUMENTATION_FAILED|INSTRUMENTATION_STATUS_CODE: -[1234]' "$evidence/instrumentation.txt"; then
  # What the screen held when the suite failed: the view dump is what a text
  # wait searches, the screenshot is what a person sees.
  "$adb" -s "$serial" shell uiautomator dump /sdcard/amber-generated-failure.xml > /dev/null 2>&1 || true
  "$adb" -s "$serial" pull /sdcard/amber-generated-failure.xml "$evidence/failure-ui.xml" > /dev/null 2>&1 || true
  "$adb" -s "$serial" exec-out screencap -p > "$evidence/failure-screen.png" 2>/dev/null || true
  "$adb" -s "$serial" shell dumpsys window windows > "$evidence/failure-windows.txt" 2>/dev/null || true
  "$adb" -s "$serial" logcat -d -v threadtime -T "$log_start" > "$evidence/logcat-tail.txt" 2>/dev/null || true
  echo "Android instrumentation failed; inspect $evidence" >&2; exit 1
fi
"$adb" -s "$serial" logcat -d -v threadtime -T "$log_start" > "$evidence/logcat-tail.txt"
cat "$evidence/logcat-live.txt" "$evidence/logcat-tail.txt" > "$evidence/logcat.txt"
grep -q 'Crystal runtime ready (probe=42)' "$evidence/logcat.txt"
grep -q 'Late-enabling -Xcheck:jni' "$evidence/logcat.txt"
awk '/AssetPipelineNative: JNI_OnLoad: starting/ { pids[$3] = 1 }
  { lines[NR] = $0; owners[NR] = $3 }
  END { for (i = 1; i <= NR; i++) if (owners[i] in pids) print lines[i] }' \
  "$evidence/logcat.txt" > "$evidence/app-logcat.txt"
if grep -Eq 'JNI DETECTED ERROR|FATAL EXCEPTION|Fatal signal|Crystal (bootstrap|render|application) error|Crystal .*callback failed|Cannot enter Crystal' "$evidence/app-logcat.txt"; then
  echo "Android runtime failure; inspect $evidence" >&2; exit 1
fi
# AndroidJUnitRunner may release the application process when ActivityScenario
# closes. Launch the saved app explicitly so the process-boundary proof begins
# with a known live process instead of depending on runner cleanup behavior.
"$adb" -s "$serial" shell am start -S -W -n "$app_id/dev.amber.generated.MainActivity" > "$evidence/first-process.txt"
for _ in $(seq 1 30); do
  previous_pid="$("$adb" -s "$serial" shell pidof "$app_id" | tr -d '\r\n')"
  [[ "$previous_pid" =~ ^[0-9]+$ ]] && break
  sleep 1
done
previous_pid="$("$adb" -s "$serial" shell pidof "$app_id" | tr -d '\r\n')"
[[ "$previous_pid" =~ ^[0-9]+$ ]] || { echo "Unable to record the first Pet Tracker process" >&2; exit 1; }
"$adb" -s "$serial" shell am force-stop "$app_id"
[[ -z "$("$adb" -s "$serial" shell pidof "$app_id" | tr -d '\r\n')" ]] || {
  echo "Pet Tracker did not stop before the cold-process check" >&2; exit 1
}
# The first suite saves Mabel. Start a distinct application process and prove
# that the shared Crystal store is restored through Android native storage.
"$adb" -s "$serial" shell am instrument -w -r -e class dev.amber.generated.NativeRestorationTest \
  "$app_id.test/androidx.test.runner.AndroidJUnitRunner" > "$evidence/restoration-instrumentation.txt" 2>&1
if ! grep -Eq '^OK \([1-9][0-9]* tests?\)' "$evidence/restoration-instrumentation.txt" ||
    ! grep -q '^INSTRUMENTATION_CODE: -1' "$evidence/restoration-instrumentation.txt" ||
    grep -Eq 'Process crashed|FAILURES!!!|INSTRUMENTATION_FAILED|INSTRUMENTATION_STATUS_CODE: -[1234]' "$evidence/restoration-instrumentation.txt"; then
  echo "Android exact-state restoration failed; inspect $evidence" >&2; exit 1
fi
# The instrumentation process is intentionally terminated when the runner
# exits. Start the restored application normally before recording its PID.
"$adb" -s "$serial" shell am start -W -n "$app_id/dev.amber.generated.MainActivity" > "$evidence/restored-process.txt"
for _ in $(seq 1 30); do
  restored_pid="$("$adb" -s "$serial" shell pidof "$app_id" | tr -d '\r\n')"
  [[ "$restored_pid" =~ ^[0-9]+$ ]] && break
  sleep 1
done
restored_pid="$("$adb" -s "$serial" shell pidof "$app_id" | tr -d '\r\n')"
[[ "$restored_pid" =~ ^[0-9]+$ && "$restored_pid" != "$previous_pid" ]]
{ awk -v pid="$restored_pid" '$3 == pid' "$evidence/logcat-live.txt"; "$adb" -s "$serial" logcat -d -v threadtime -T "$log_start" --pid="$restored_pid"; } > "$evidence/restoration-logcat.txt"
grep -q 'Crystal runtime ready (probe=42)' "$evidence/restoration-logcat.txt"
if grep -Eq 'JNI DETECTED ERROR|FATAL EXCEPTION|Fatal signal|Crystal (bootstrap|render|application) error|Crystal .*callback failed|Cannot enter Crystal' "$evidence/restoration-logcat.txt"; then
  echo "Restoration process failed; inspect $evidence" >&2; exit 1
fi
"$adb" -s "$serial" shell am start -S -W -n "$app_id/dev.amber.generated.MainActivity" > "$evidence/relaunch.txt"
for _ in $(seq 1 30); do
  "$adb" -s "$serial" shell uiautomator dump /sdcard/amber-generated-proof-top.xml > /dev/null 2>&1 || true
  "$adb" -s "$serial" pull /sdcard/amber-generated-proof-top.xml "$evidence/relaunch-ui-top.xml" > /dev/null 2>&1 || true
  if [[ -s "$evidence/relaunch-ui-top.xml" ]] &&
      grep -q 'Pet Tracker' "$evidence/relaunch-ui-top.xml" &&
      grep -q 'Restored from this device.' "$evidence/relaunch-ui-top.xml"; then
    break
  fi
  sleep 1
done
grep -q 'Pet Tracker' "$evidence/relaunch-ui-top.xml"
grep -q 'Restored from this device.' "$evidence/relaunch-ui-top.xml"
for _ in 1 2 3; do
  "$adb" -s "$serial" shell input swipe 540 1950 540 450 500 > /dev/null 2>&1 || true
  sleep 1
done
"$adb" -s "$serial" shell uiautomator dump /sdcard/amber-generated-proof-pet.xml > /dev/null 2>&1
"$adb" -s "$serial" pull /sdcard/amber-generated-proof-pet.xml "$evidence/relaunch-ui-pet.xml" > /dev/null
grep -q 'Mabel' "$evidence/relaunch-ui-pet.xml"
"$adb" -s "$serial" exec-out screencap -p > "$evidence/relaunch.png"
"$adb" -s "$serial" shell pidof "$app_id" > "$evidence/relaunch-pid.txt"
relaunch_pid="$(tr -d '\r\n' < "$evidence/relaunch-pid.txt")"
[[ "$relaunch_pid" =~ ^[0-9]+$ ]]
[[ "$relaunch_pid" != "$previous_pid" && "$relaunch_pid" != "$restored_pid" ]] || {
  echo "Persistence test did not start a third process" >&2; exit 1
}
{ awk -v pid="$relaunch_pid" '$3 == pid' "$evidence/logcat-live.txt"; "$adb" -s "$serial" logcat -d -v threadtime -T "$log_start" --pid="$relaunch_pid"; } > "$evidence/relaunch-logcat.txt"
grep -q 'Crystal runtime ready (probe=42)' "$evidence/relaunch-logcat.txt"
if grep -Eq 'JNI DETECTED ERROR|FATAL EXCEPTION|Fatal signal|Crystal (bootstrap|render|application) error|Crystal .*callback failed|Cannot enter Crystal' "$evidence/relaunch-logcat.txt"; then
  echo "Relaunched Android process failed; inspect $evidence" >&2; exit 1
fi
bash "$script_dir/inspect_artifacts.sh" "$evidence/artifacts"
echo "Android application tests passed. Evidence: $evidence"
