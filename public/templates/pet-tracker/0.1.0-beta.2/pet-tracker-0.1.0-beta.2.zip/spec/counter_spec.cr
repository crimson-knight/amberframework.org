require "spec"
require "../src/app/pets/pet_store"

describe PetTracker::Store do
  it "shares save and adoption rules without a platform dependency" do
    store = PetTracker::Store.new([] of PetSummary)
    pet = store.save("Mabel", "Dog")
    pet.adopted.should be_false
    store.toggle_adopted(pet.id).adopted.should be_true
  end

  it "round-trips the local native snapshot" do
    source = PetTracker::Store.new
    restored = PetTracker::Store.new([] of PetSummary)
    restored.restore(source.serialize).should be_true
    restored.snapshot.pets.map(&.name).should eq(["Mochi", "Rocky", "Pip"])
  end
end
