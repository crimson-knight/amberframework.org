require "asset_pipeline/amber_integration"
require "../../app/pets/pet_store"

class PetTrackerScreen < UI::Screen
  PET_CREAM        = UI::Color.new(r: 1.0, g: 0.976, b: 0.937)
  PET_PAPER        = UI::Color.new(r: 1.0, g: 0.992, b: 0.976)
  PET_ORANGE       = UI::Color.new(r: 0.957, g: 0.478, b: 0.086)
  PET_INK          = UI::Color.new(r: 0.129, g: 0.098, b: 0.078)
  PET_MUTED        = UI::Color.new(r: 0.463, g: 0.404, b: 0.365)
  PET_LINE         = UI::Color.new(r: 0.914, g: 0.827, b: 0.725)
  PET_TEAL         = UI::Color.new(r: 0.078, g: 0.498, b: 0.502)
  PET_TEAL_SOFT    = UI::Color.new(r: 0.886, g: 0.945, b: 0.937)
  PET_WAITING      = UI::Color.new(r: 0.663, g: 0.294, b: 0.043)
  PET_WAITING_SOFT = UI::Color.new(r: 1.0, g: 0.941, b: 0.843)
  PET_WHITE        = UI::Color.new(r: 1.0, g: 1.0, b: 1.0)

  def initialize(
    @state : PetTrackerState = PetTracker.store.snapshot,
    @name : String = "",
    @species : String = "",
    @on_name_change : Proc(String, Nil)? = nil,
    @on_species_change : Proc(String, Nil)? = nil,
    @on_save : Proc(Nil)? = nil,
    @on_toggle_adopted : Proc(Int64, Nil)? = nil,
    @native_content_width : Float64? = nil,
  )
  end

  def build(context : UI::ScreenContext) : UI::View
    screen = UI::VStack.new(spacing: 24.0, alignment: UI::Alignment::Leading)
    screen.padding = UI::EdgeInsets.new(top: 28.0, trailing: 24.0, bottom: 36.0, leading: 24.0)
    screen.test_id = "pet-tracker-screen"
    unless web?(context)
      screen.fill_horizontal = true
      screen.background = PET_CREAM
    end
    screen << build_header(context)

    unless @state.notice.empty?
      notice = UI::Label.new(@state.notice)
      notice.test_id = "pet-notice"
      unless web?(context)
        notice.fill_horizontal = true
        notice.padding = UI::EdgeInsets.new(top: 10.0, trailing: 12.0, bottom: 10.0, leading: 12.0)
        notice.background = PET_PAPER
        notice.text_color = PET_MUTED
        notice.corner_radius = 10.0
      end
      screen << notice
    end

    screen << build_new_pet_form(context)
    heading = UI::Label.new("Our pets")
    heading.font = UI::Font.new(size: 30.0, weight: :bold)
    heading.accessibility_role = :header
    heading.test_id = "pets-heading"
    heading.text_color = PET_INK unless web?(context)
    screen << heading
    screen << build_pet_list(context)

    if web?(context)
      screen << build_kindness_note
      screen << build_footer(context)
    end

    screen
  end

  private def build_header(context : UI::ScreenContext) : UI::View
    header = UI::HStack.new(spacing: 16.0, alignment: UI::Alignment::Center)
    header.test_id = "pet-tracker-header"
    header.fill_horizontal = true unless web?(context)

    brand = UI::HStack.new(spacing: 14.0, alignment: UI::Alignment::Center)
    brand.test_id = "pet-brand"

    mark = UI::Image.new(brand_mark_source(context))
    mark.content_mode = UI::ContentMode::Fit
    mark.minimum_width = mark.maximum_width = 52.0
    mark.minimum_height = mark.maximum_height = 52.0
    mark.accessibility_label = "Pet Tracker paw"
    mark.test_id = "pet-brand-mark"

    words = UI::VStack.new(spacing: 2.0, alignment: UI::Alignment::Leading)
    words.test_id = "pet-brand-copy"
    title = UI::Label.new("Pet Tracker")
    title.font = UI::Font.new(size: 32.0, weight: :bold)
    title.accessibility_role = :header
    title.test_id = "pet-title"
    subtitle = UI::Label.new("Everyone deserves a good home.")
    subtitle.font = UI::Font.new(size: 16.0)
    subtitle.test_id = "pet-subtitle"
    unless web?(context)
      title.text_color = PET_INK
      subtitle.text_color = PET_MUTED
    end

    words << title
    words << subtitle
    brand << mark
    brand << words
    header << brand
    header << UI::Spacer.new

    if web?(context)
      navigation = UI::HStack.new(spacing: 24.0, alignment: UI::Alignment::Center)
      navigation.test_id = "pet-desktop-nav"
      navigation << navigation_link("Home", "#top", "pet-nav-home")
      navigation << navigation_link("Pets", "#pets", "pet-nav-pets")
      navigation << navigation_link("About", "#about", "pet-nav-about")
      header << navigation
    end

    menu = UI::Button.new("☰", style: UI::ButtonStyle::Borderless)
    menu.accessibility_label = "Open navigation"
    menu.test_id = "pet-mobile-menu"
    menu.foreground_color = PET_INK unless web?(context)
    header << menu
    header
  end

  private def navigation_link(label : String, url : String, test_id : String) : UI::LinkButton
    link = UI::LinkButton.new(label, url)
    link.opens_in_browser = false
    link.test_id = test_id
    link
  end

  private def build_new_pet_form(context : UI::ScreenContext) : UI::View
    name = UI::TextField.new(
      placeholder: "Enter a name",
      name: "name",
      text: context.params["name"]? || @name,
    ) { |value| @on_name_change.try(&.call(value)) }
    name.accessibility_label = "Pet name"
    name.test_id = "pet-name"

    species = UI::TextField.new(
      placeholder: "Select a species",
      name: "species",
      text: context.params["species"]? || @species,
    ) { |value| @on_species_change.try(&.call(value)) }
    species.accessibility_label = "Pet species"
    species.accessibility_hint = "Choose Cat, Dog, or Rabbit"
    species.test_id = "pet-species"

    save = UI::Button.new("Save pet", type: UI::Button::Type::Submit) do
      @on_save.try(&.call)
    end
    save.style = UI::ButtonStyle::Prominent
    save.test_id = "save-pet"

    if web?(context)
      form = UI::Form.new(action: "/pets", csrf_token: context.csrf_token)
      form.test_id = "new-pet-form"
      fields = form.add_section(header: "Add a pet")
      fields.fields << UI::Form::Field.new(label: "Name", content: name)
      fields.fields << UI::Form::Field.new(label: "Species", content: species)
      fields.fields << UI::Form::Field.new(content: save)
      return form
    end

    form = UI::VStack.new(spacing: 8.0, alignment: UI::Alignment::Fill)
    form.test_id = "new-pet-form"
    form.fill_horizontal = true
    form.padding = UI::EdgeInsets.new(top: 18.0, trailing: 18.0, bottom: 18.0, leading: 18.0)
    form.background = PET_PAPER
    form.corner_radius = 16.0
    form.border_width = 1.0
    form.border_color = PET_LINE

    form_title = UI::Label.new("Add a pet")
    form_title.font = UI::Font.new(size: 22.0, weight: :bold)
    form_title.text_color = PET_INK
    form_title.accessibility_role = :header

    name_label = UI::Label.new("Name")
    name_label.font = UI::Font.new(size: 15.0, weight: :bold)
    name_label.text_color = PET_INK
    species_label = UI::Label.new("Species")
    species_label.font = UI::Font.new(size: 15.0, weight: :bold)
    species_label.text_color = PET_INK

    name.fill_horizontal = true
    name.minimum_height = 52.0
    species.fill_horizontal = true
    species.minimum_height = 52.0
    save.fill_horizontal = true
    save.minimum_height = 52.0
    save.background = PET_ORANGE
    save.foreground_color = PET_WHITE
    save.corner_radius = 10.0

    form << form_title
    form << name_label
    form << name
    form << species_label
    form << species
    form << save
    form
  end

  private def build_pet_list(context : UI::ScreenContext) : UI::View
    if @state.pets.empty?
      empty = UI::Label.new("No pets yet. Add the first one above.")
      empty.test_id = "empty-pets"
      return empty
    end

    rows = @state.pets.map { |pet| build_pet_card(context, pet).as(UI::View) }
    list = UI::ListView.flat(rows)
    list.test_id = "pet-list"
    list
  end

  private def build_pet_card(context : UI::ScreenContext, pet : PetSummary) : UI::View
    content = UI::VStack.new(spacing: 14.0, alignment: UI::Alignment::Leading)
    content.test_id = "pet-card-content-#{pet.id}"
    summary = UI::HStack.new(spacing: 12.0, alignment: UI::Alignment::Center)
    summary.test_id = "pet-summary-#{pet.id}"

    image = UI::Image.new(image_source(context, pet.species))
    image.content_mode = UI::ContentMode::Fit
    image.minimum_width = image.maximum_width = 72.0
    image.minimum_height = image.maximum_height = 72.0
    image.accessibility_label = "Portrait of #{pet.name}, #{pet.species}"
    image.test_id = "pet-avatar-#{pet.id}"
    unless web?(context)
      image.background = PET_CREAM
      image.corner_radius = 12.0
    end

    copy = UI::VStack.new(spacing: 3.0, alignment: UI::Alignment::Leading)
    copy.test_id = "pet-copy-#{pet.id}"
    name = UI::Label.new(pet.name)
    name.font = UI::Font.new(size: 20.0, weight: :bold)
    name.test_id = "pet-name-#{pet.id}"
    species = UI::Label.new(pet.species)
    species.test_id = "pet-species-label-#{pet.id}"
    unless web?(context)
      name.text_color = PET_INK
      species.text_color = PET_MUTED
    end
    copy << name
    copy << species
    status = UI::Label.new(pet.adopted ? "Adopted" : "Looking for a home")
    status.test_id = pet.adopted ? "pet-status-adopted-#{pet.id}" : "pet-status-waiting-#{pet.id}"
    unless web?(context)
      status.padding = UI::EdgeInsets.new(top: 5.0, trailing: 9.0, bottom: 5.0, leading: 9.0)
      status.corner_radius = 14.0
      status.background = pet.adopted ? PET_TEAL_SOFT : PET_WAITING_SOFT
      status.text_color = pet.adopted ? PET_TEAL : PET_WAITING
      status.font = UI::Font.new(size: 14.0, weight: :bold)
    end
    copy << status
    summary << image
    summary << copy
    content << summary

    if web?(context)
      action_row = UI::HStack.new(spacing: 10.0, alignment: UI::Alignment::Center)
      action_row.fill_equally = true
      action_row.test_id = "pet-actions-#{pet.id}"

      details_form = UI::Form.new(action: "/pets/#{pet.id}/details", csrf_token: context.csrf_token)
      details = details_form.add_section
      details_button = UI::Button.new("View details", style: UI::ButtonStyle::Bordered, type: UI::Button::Type::Submit)
      details_button.test_id = "details-pet-#{pet.id}"
      details.fields << UI::Form::Field.new(content: details_button)

      edit_form = UI::Form.new(action: "/pets/#{pet.id}/toggle-adopted", csrf_token: context.csrf_token)
      edit = edit_form.add_section
      edit_button = UI::Button.new("Edit", style: UI::ButtonStyle::Bordered, type: UI::Button::Type::Submit) do
        @on_toggle_adopted.try(&.call(pet.id))
      end
      edit_button.test_id = "toggle-pet-#{pet.id}"
      edit.fields << UI::Form::Field.new(content: edit_button)

      action_row << details_form
      action_row << edit_form
      content << action_row
    end

    unless web?(context)
      content.fill_horizontal = true
      content.padding = UI::EdgeInsets.new(top: 12.0, trailing: 14.0, bottom: 12.0, leading: 14.0)
      content.background = PET_PAPER
      content.corner_radius = 16.0
      content.border_width = 1.0
      content.border_color = PET_LINE
      content.minimum_width = @native_content_width if @native_content_width
    end

    card = UI::Card.new(content)
    card.test_id = "pet-card-#{pet.id}"
    unless web?(context)
      card.content_padding = UI::EdgeInsets.new
      card.corner_radius = 16.0
    end
    card
  end

  private def build_kindness_note : UI::Card
    row = UI::HStack.new(spacing: 14.0, alignment: UI::Alignment::Center)
    row.test_id = "pet-kindness-note"
    heart = UI::Label.new("♥")
    heart.font = UI::Font.new(size: 30.0, weight: :bold)
    heart.accessibility_label = "Kindness"
    heart.test_id = "pet-kindness-heart"
    copy = UI::VStack.new(spacing: 3.0, alignment: UI::Alignment::Leading)
    copy << UI::Label.new("Small pets.")
    copy << UI::Label.new("Big brighter tomorrows.")
    row << heart
    row << copy
    card = UI::Card.new(row)
    card.test_id = "pet-kindness-card"
    card
  end

  private def build_footer(context : UI::ScreenContext) : UI::View
    footer = UI::HStack.new(spacing: 18.0, alignment: UI::Alignment::Center)
    footer.test_id = "pet-footer"

    identity = UI::VStack.new(spacing: 2.0, alignment: UI::Alignment::Leading)
    identity.test_id = "pet-footer-identity"
    name = UI::Label.new("Pet Tracker")
    name.font = UI::Font.new(size: 17.0, weight: :bold)
    identity << name
    identity << UI::Label.new("Everyone deserves a good home.")

    promise = UI::HStack.new(spacing: 8.0, alignment: UI::Alignment::Center)
    promise.test_id = "pet-footer-promise"
    mark = UI::Image.new(brand_mark_source(context))
    mark.content_mode = UI::ContentMode::Fit
    mark.minimum_width = mark.maximum_width = 28.0
    mark.minimum_height = mark.maximum_height = 28.0
    mark.accessibility_label = "Pet Tracker paw"
    promise << mark
    promise << UI::Label.new("Compassion today. Brighter tomorrows.")

    footer << identity
    footer << UI::Spacer.new
    footer << promise
    footer
  end

  private def brand_mark_source(context : UI::ScreenContext) : String
    web?(context) ? "/assets/pets/paw-mark.webp" : "pet-tracker/paw-mark"
  end

  private def image_source(context : UI::ScreenContext, species : String) : String
    slug = case species.downcase
           when "cat"    then "mochi-cat"
           when "dog"    then "rocky-dog"
           when "rabbit" then "pip-rabbit"
           else               return ""
           end
    web?(context) ? "/assets/pets/#{slug}.webp" : "pet-tracker/#{slug}"
  end

  private def web?(context : UI::ScreenContext) : Bool
    context.platform.to_s.starts_with?("web")
  end
end
