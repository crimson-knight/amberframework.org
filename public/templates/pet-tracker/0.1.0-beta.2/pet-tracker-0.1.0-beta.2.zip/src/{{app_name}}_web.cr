require "amber"
require "./platform/web/pet_controller"

Amber.settings.name = "{{display_name}}"
Amber.settings.host = ENV["HOST"]? || "127.0.0.1"
Amber.settings.port = (ENV["PORT"]? || "3000").to_i

Amber::Server.configure do
  pipeline :web do
    plug Amber::Pipe::Error.new
    plug Amber::Pipe::Session.new
    plug Amber::Pipe::CSRF.new
  end
  pipeline :static do
    plug Amber::Pipe::Error.new
    plug Amber::Pipe::Static.new("./public")
  end
  routes :web do
    get "/", App::WebPetController, :index
    post "/pets", App::WebPetController, :create
    post "/pets/:id/details", App::WebPetController, :details
    post "/pets/:id/toggle-adopted", App::WebPetController, :toggle_adopted
  end
  routes :static do
    get "/*", Amber::Controller::Static, :index
  end
end

Amber::Server.start
