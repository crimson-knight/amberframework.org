require "html"
require "asset_pipeline/amber_integration"
require "../../views/pet/pet_tracker_screen"

module App
  class WebPetController < Amber::Controller::Base
    @notice_message : String = ""

    def index
      page
    end

    def create
      PetTracker.store.save(params["name"]?.to_s, params["species"]?.to_s)
      redirect_to "/"
    rescue error : ArgumentError
      @notice_message = error.message || "Please check the pet details"
      response.status_code = 422
      page
    end

    def details
      id = params["id"].to_s.to_i64
      pet = PetTracker.store.snapshot.pets.find { |candidate| candidate.id == id }
      raise ArgumentError.new("Pet #{id} was not found") unless pet
      status = pet.adopted ? "already has a home" : "is looking for a home"
      @notice_message = "#{pet.name} is a #{pet.species.downcase} who #{status}."
      page
    rescue error : ArgumentError
      @notice_message = error.message || "That pet could not be found"
      response.status_code = 404
      page
    end

    def toggle_adopted
      PetTracker.store.toggle_adopted(params["id"].to_s.to_i64)
      redirect_to "/"
    rescue error : ArgumentError
      @notice_message = error.message || "That pet could not be updated"
      response.status_code = 404
      page
    end

    private def page : String
      response.content_type = "text/html; charset=utf-8"
      context = UI::ScreenContext::Web.new(
        params: scalar_params,
        params_multi: {} of String => Array(String),
        flash_data: @notice_message.empty? ? {} of String => String : {"notice" => @notice_message},
        design_tokens: UI::DesignTokens::Tokens.default,
        csrf_token: csrf_token,
      )
      screen = PetTrackerScreen.new(PetTracker.store.snapshot(@notice_message))
      renderer = UI::Web::Renderer.new
      body = renderer.render(
        screen.build(context),
        render_context: UI::RenderContext.new(csrf_token: context.csrf_token),
      )
      <<-HTML
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pet Tracker · {{display_name}}</title>
    <link rel="stylesheet" href="/assets/pet-tracker.css">
  </head>
  <body><main class="pet-tracker">#{body}</main></body>
</html>
HTML
    end

    private def scalar_params : Hash(String, String)
      result = {} of String => String
      params.to_h.each do |key, value|
        result[key.to_s] = value.is_a?(Array(String)) ? (value.first? || "") : value.to_s
      end
      result
    end
  end
end
