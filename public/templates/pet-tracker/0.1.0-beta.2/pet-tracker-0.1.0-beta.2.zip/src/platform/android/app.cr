require "asset_pipeline/ui/android/application"
require "amber/native/android_storage"
require "../../views/pet/pet_tracker_screen"
require "./configuration"

module App::Android
  class PetScreenContext < UI::ScreenContext
    getter params : Hash(String, String) = {} of String => String
    getter params_multi : Hash(String, Array(String)) = {} of String => Array(String)
    getter flash_data : Hash(String, String) = {} of String => String
    getter design_tokens : UI::DesignTokens::Tokens = UI::DesignTokens::Tokens.default
    getter csrf_token : String? = nil

    def platform : Symbol
      :android
    end
  end

  @@storage : Amber::Native::Storage = Amber::Native::Android::Storage.new
  @@name = ""
  @@species = ""
  @@notice = "Loading your pets..."
  @@ready = false
  @@loading = false

  def self.load : Nil
    return if @@ready || @@loading
    @@loading = true
    @@storage.read("pet-tracker.snapshot.v1") do |result|
      case result
      when String
        @@notice = PetTracker.store.restore(result) ? "Restored from this device." : "The saved pet list was invalid; the starter pets are still here."
      when Amber::Native::ServiceError
        @@notice = "Local storage is unavailable: #{result.code}."
      else
        @@notice = "Your pets are ready."
      end
      @@loading = false
      @@ready = true
      UI::Android::Application.invalidate
    end
  end

  def self.persist : Nil
    @@storage.write("pet-tracker.snapshot.v1", PetTracker.store.serialize) do |result|
      @@notice = result.is_a?(Amber::Native::ServiceError) ? "Save failed: #{result.code}." : "Saved on this device."
      UI::Android::Application.invalidate
    end
  end

  def self.screen : UI::View
    context = PetScreenContext.new
    return UI::Label.new(@@notice) unless @@ready
    content_width = ((UI::Android::Application.viewport.try(&.content_width) || 360.0) - 48.0).clamp(240.0, 720.0)
    PetTrackerScreen.new(
      state: PetTracker.store.snapshot(@@notice),
      name: @@name,
      species: @@species,
      on_name_change: ->(value : String) { @@name = value },
      on_species_change: ->(value : String) { @@species = value },
      on_save: -> {
        begin
          PetTracker.store.save(@@name, @@species)
          @@name = ""
          @@species = ""
          persist
        rescue error : ArgumentError
          @@notice = error.message || "Please check the pet details"
        end
        UI::Android::Application.invalidate
      },
      on_toggle_adopted: ->(id : Int64) {
        PetTracker.store.toggle_adopted(id)
        persist
        UI::Android::Application.invalidate
      },
      native_content_width: content_width,
    ).build(context)
  end
end

UI::Android::Application.on_lifecycle do |event|
  App::Android.load if event.foreground?
end
UI::Android::Application.configure { |_route| App::Android.screen }
